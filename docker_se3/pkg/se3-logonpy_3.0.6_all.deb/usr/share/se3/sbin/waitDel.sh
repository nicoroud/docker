#!/bin/bash
# $Id$
# attend un peu avant d'effacer un fichier lock
# usage $0 fichier tempo (secondes)
sleep $2s
rm -f $1

